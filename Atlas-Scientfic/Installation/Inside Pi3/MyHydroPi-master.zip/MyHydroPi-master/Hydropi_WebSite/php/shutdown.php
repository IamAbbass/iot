<?php
// SHUTDOWN.PHP
// Call python script to shutdown Pi
exec ("python /var/www/html/python/shutdown.py");

?>