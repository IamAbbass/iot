<?php
// RESTART.PHP
//call python code to restart the Pi
exec ("python /var/www/html/python/restart.py");

?>