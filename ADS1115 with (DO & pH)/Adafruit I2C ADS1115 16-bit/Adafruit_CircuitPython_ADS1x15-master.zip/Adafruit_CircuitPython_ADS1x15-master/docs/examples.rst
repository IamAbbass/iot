Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ads1015_simpletest.py
    :caption: examples/ads1015_simpletest.py
    :linenos:

.. literalinclude:: ../examples/ads1115_simpletest.py
    :caption: examples/ads1115_simpletest.py
    :linenos:
